# =============================================================================
# db.py
# SQLite data access layer. Pure database reads and writes — no business logic.
# Each public function handles exactly one query. index.py calls these;
# it never touches sqlite3 directly.
# =============================================================================

import sqlite3
import sys

# -----------------------------------------------------------------------------
# INTERNAL HELPER
# -----------------------------------------------------------------------------

def _connect(db_path):
    """Open a WAL-mode connection and return rows as dicts."""
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.row_factory = sqlite3.Row
        return conn
    except sqlite3.Error as e:
        print(f"[db] FATAL — cannot connect to '{db_path}': {e}", file=sys.stderr)
        sys.exit(1)

# -----------------------------------------------------------------------------
# PUBLIC READ FUNCTIONS
# -----------------------------------------------------------------------------

def fetch_all_settings(db_path):
    """
    Return all rows from settings_boolean as a list of dicts.
    Keys: id, setting_name, setting_bool
    """
    conn = _connect(db_path)
    rows = conn.execute("SELECT * FROM settings_boolean").fetchall()
    conn.close()
    return [dict(row) for row in rows]


def fetch_all_prompts(db_path):
    """
    Return all rows from agent_prompts as a list of dicts.
    Keys: id, prompt_name, prompt_body, prompt_enabled
    """
    conn = _connect(db_path)
    rows = conn.execute("SELECT * FROM agent_prompts").fetchall()
    conn.close()
    return [dict(row) for row in rows]


def fetch_all_functions(db_path):
    """
    Return all rows from functions as a list of dicts.
    Includes function_body for runtime execution.
    Keys: id, function_name, function_description, function_body,
          function_language, function_created, function_modified, function_enabled
    """
    conn = _connect(db_path)
    rows = conn.execute("SELECT * FROM functions").fetchall()
    conn.close()
    return [dict(row) for row in rows]


def fetch_function_by_name(db_path, function_name):
    """
    Retrieve a single function row by exact function_name.
    Returns a dict or None if not found.
    Used at execution time when the agent calls a specific function.
    """
    conn = _connect(db_path)
    row = conn.execute(
        "SELECT * FROM functions WHERE function_name = ? AND function_enabled = 1",
        (function_name,)
    ).fetchone()
    conn.close()
    return dict(row) if row else None
