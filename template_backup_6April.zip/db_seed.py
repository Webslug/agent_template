# =============================================================================
# db_seed.py
# Responsible for: creating the SQLite database, enforcing table schemas,
# and seeding default data on first boot.
#
# Called by index.py when database.db is not found on disk.
# Can also be run standalone to reset/repopulate the database.
#
# USAGE:
#   python db_seed.py
# =============================================================================

import sqlite3
import datetime
import sys
from db_functions import SEED_FUNCTIONS

# -----------------------------------------------------------------------------
# CONSTANTS
# -----------------------------------------------------------------------------

DB_PATH = "database.db"

# -----------------------------------------------------------------------------
# SCHEMA DEFINITIONS
# Each tuple: (table_name, CREATE TABLE SQL)
# -----------------------------------------------------------------------------

SCHEMA = [
    (
        "settings_boolean",
        """
        CREATE TABLE IF NOT EXISTS settings_boolean (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            setting_name TEXT    UNIQUE NOT NULL,
            setting_bool INTEGER DEFAULT 1
        )
        """
    ),
    (
        "agent_prompts",
        """
        CREATE TABLE IF NOT EXISTS agent_prompts (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            prompt_name    TEXT    NOT NULL,
            prompt_body    TEXT    NOT NULL,
            prompt_enabled INTEGER DEFAULT 1
        )
        """
    ),
    (
        "functions",
        """
        CREATE TABLE IF NOT EXISTS functions (
            id                   INTEGER PRIMARY KEY AUTOINCREMENT,
            function_name        TEXT    NOT NULL,
            function_description TEXT    NOT NULL,
            function_body        TEXT    NOT NULL,
            function_language    TEXT    NOT NULL DEFAULT 'python',
            function_created     DATETIME NOT NULL,
            function_modified    DATETIME NOT NULL,
            function_enabled     INTEGER  DEFAULT 1
        )
        """
    ),
]

# -----------------------------------------------------------------------------
# SEED DATA
# -----------------------------------------------------------------------------

SEED_SETTINGS = [
    # (setting_name, setting_bool)
    ("INTERACTIVE_MODE", 1),   # 0 = stateless/daemon, 1 = interactive readline
    ("DEBUG_LOGGING",    0),   # reserved for future verbose output toggle
]

SEED_PROMPTS = [
    # (prompt_name, prompt_body, prompt_enabled)
    (
        "DEFAULT",
        (
            "You are a disciplined AI agent operating in a structured execution environment.\n"
            "You have access to a roster of callable functions listed below.\n\n"

            "════════════════════════════════════════\n"
            "CALL SYNTAX — THE ONLY VALID FORMAT\n"
            "════════════════════════════════════════\n"
            "To invoke a function you MUST emit EXACTLY this on its own line:\n"
            "  CALL: function_name\n\n"
            "Some functions accept parameters on the same line:\n"
            "  CALL: calculate expr=<python_expression>\n"
            "  CALL: set_setting setting_name=<name> setting_value=<0_or_1>\n\n"
            "FORBIDDEN — these formats will BREAK the system, NEVER use them:\n"
            "  <tool_call>anything</tool_call>   ← FORBIDDEN\n"
            "  <function_call>anything</function_call>   ← FORBIDDEN\n"
            "  Any XML tag whatsoever   ← FORBIDDEN\n\n"

            "REASONING PROTOCOL:\n"
            "Think through every task inside a <SCRATCHPAD> block before acting.\n"
            "Use the scratchpad to plan which functions are needed and in what order.\n\n"
            "The system will execute the function and inject the real output as:\n"
            "  RESULT: <output>\n\n"
            "You may then reason further in another <SCRATCHPAD> block before the next CALL.\n"
            "Chain as many CALL/RESULT cycles as the task requires.\n"
            "Never invent or simulate a RESULT. Always wait for the system to supply it.\n\n"
            "FINAL ANSWER — when all calls are complete emit:\n"
            "  FINAL: your answer here\n\n"
            "RULES:\n"
            "1. Always open with a <SCRATCHPAD> block.\n"
            "2. One CALL per response — never stack multiple CALLs in one reply.\n"
            "3. FINAL: must appear alone on its line, never alongside a CALL.\n"
            "4. Do not repeat information already confirmed by a RESULT.\n"
            "5. Use every RESULT VERBATIM — never substitute values from memory or training data.\n"
            "6. CALL: is the ONLY way to invoke functions. XML tags are FORBIDDEN.\n\n"

            "EXAMPLES:\n"
            "User: enable debug mode\n"
            "<SCRATCHPAD>I need to set DEBUG_LOGGING to 1. I will call enable_debug_mode.</SCRATCHPAD>\n"
            "CALL: enable_debug_mode\n"
            "RESULT: DEBUG_LOGGING set to 1 (debug mode enabled).\n"
            "FINAL: Debug mode has been enabled.\n\n"

            "User: what is 6 * 7?\n"
            "<SCRATCHPAD>I will use calculate to evaluate the expression.</SCRATCHPAD>\n"
            "CALL: calculate expr=6 * 7\n"
            "RESULT: 42\n"
            "FINAL: 6 * 7 = 42.\n\n"

            "User: what time is it?\n"
            "<SCRATCHPAD>I need the current time. I will call get_current_datetime.</SCRATCHPAD>\n"
            "CALL: get_current_datetime\n"
            "RESULT: 2026-04-05 19:13:17\n"
            "FINAL: The current time is 19:13:17.\n\n"

            "User: what date is it in 3 days?\n"
            "<SCRATCHPAD>First get today's date, then add 3 days with calculate.</SCRATCHPAD>\n"
            "CALL: get_current_datetime\n"
            "RESULT: 2026-04-05 18:40:00\n"
            "<SCRATCHPAD>Today is 2026-04-05. I will add 3 days using calculate with the pre-injected datetime module.</SCRATCHPAD>\n"
            "CALL: calculate expr=datetime.date(2026,4,5)+datetime.timedelta(days=3)\n"
            "RESULT: 2026-04-08\n"
            "FINAL: The date in 3 days is 2026-04-08.\n\n"

            "WRONG — never do this:\n"
            "User: what time is it?\n"
            "<tool_call>get_current_datetime</tool_call>   ← WRONG, XML tags are FORBIDDEN\n"
            "<tool_call>I will use get_current_datetime</tool_call>   ← WRONG\n"
            "The correct form is always: CALL: get_current_datetime\n\n"

            "Available functions:"
        ),
        1
    ),
]


# -----------------------------------------------------------------------------
# INTERNAL HELPERS
# -----------------------------------------------------------------------------

def _now():
    """Return current UTC datetime as ISO string."""
    return datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")


def _enforce_schema(cursor):
    """Create all tables if they do not already exist."""
    for table_name, ddl in SCHEMA:
        cursor.execute(ddl)
    print(f"  [schema]   Tables verified: {[t for t, _ in SCHEMA]}")


def _seed_settings(cursor):
    """Insert default settings_boolean rows, skip if setting_name already exists."""
    inserted = 0
    for name, val in SEED_SETTINGS:
        cursor.execute(
            "INSERT OR IGNORE INTO settings_boolean (setting_name, setting_bool) VALUES (?, ?)",
            (name, val)
        )
        if cursor.rowcount > 0:
            inserted += 1
    print(f"  [settings] Seeded {inserted}/{len(SEED_SETTINGS)} setting(s).")


def _seed_prompts(cursor):
    """Insert default agent_prompts rows if prompt_name does not already exist."""
    inserted = 0
    for name, body, enabled in SEED_PROMPTS:
        existing = cursor.execute(
            "SELECT id FROM agent_prompts WHERE prompt_name = ?", (name,)
        ).fetchone()
        if not existing:
            cursor.execute(
                "INSERT INTO agent_prompts (prompt_name, prompt_body, prompt_enabled) VALUES (?, ?, ?)",
                (name, body, enabled)
            )
            inserted += 1
    print(f"  [prompts]  Seeded {inserted}/{len(SEED_PROMPTS)} prompt(s).")


def _seed_functions(cursor):
    """Insert default function rows if function_name does not already exist."""
    inserted = 0
    now = _now()
    for name, description, body, language in SEED_FUNCTIONS:
        existing = cursor.execute(
            "SELECT id FROM functions WHERE function_name = ?", (name,)
        ).fetchone()
        if not existing:
            cursor.execute(
                """
                INSERT INTO functions
                    (function_name, function_description, function_body,
                     function_language, function_created, function_modified, function_enabled)
                VALUES (?, ?, ?, ?, ?, ?, 1)
                """,
                (name, description, body, language, now, now)
            )
            inserted += 1
    print(f"  [functions] Seeded {inserted}/{len(SEED_FUNCTIONS)} function(s).")

# -----------------------------------------------------------------------------
# PUBLIC ENTRY POINT
# -----------------------------------------------------------------------------

def run(db_path=DB_PATH):
    """
    Main seed routine. Safe to call repeatedly — all inserts are idempotent.
    Creates database.db if it does not exist, enforces schema, seeds defaults.
    """
    print(f"[db_seed] Initializing database: {db_path}")
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA journal_mode=WAL;")
        cursor = conn.cursor()

        _enforce_schema(cursor)
        _seed_settings(cursor)
        _seed_prompts(cursor)
        _seed_functions(cursor)

        conn.commit()
        conn.close()
        print(f"[db_seed] Done. Database ready at: {db_path}\n")

    except sqlite3.Error as e:
        print(f"[db_seed] FATAL — SQLite error: {e}", file=sys.stderr)
        sys.exit(1)


# Allow standalone execution
if __name__ == "__main__":
    run()
