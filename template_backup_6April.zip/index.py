# =============================================================================
# index.py
# Root command file. Responsible for:
#   - Defining all runtime constants
#   - Bootstrapping the database via db_seed.py if absent
#   - Loading all tables into memory arrays
#   - Assembling the final system prompt
#   - Entering interactive or stateless execution loop
#
# USAGE:
#   python index.py
# =============================================================================

import os
import sys
import json
import urllib.request
import urllib.error
import readline  # noqa: F401 — activates readline editing in interactive mode

import db
import db_seed

# -----------------------------------------------------------------------------
# CONSTANTS
# Edit these to reconfigure the agent for a given deployment.
# -----------------------------------------------------------------------------

DB_PATH          = "database.db"
DEFAULT_PROMPT   = "DEFAULT"
MCP_PORT         = "8206"
ENDPOINT_KOBOLD  = "http://localhost:5001/api/v1/generate"
ENDPOINT_OLLAMA  = "http://localhost:11434/api/generate"
ANTI_PROMPTS     = ["User:", "<|im_end|>", "\n\n\n"]

# Kobold generation parameters — tune as needed
KOBOLD_MAX_TOKENS  = 512
KOBOLD_TEMPERATURE = 0.1
KOBOLD_TOP_P       = 0.9

# -----------------------------------------------------------------------------
# BOOT SEQUENCE
# -----------------------------------------------------------------------------

def _boot_database():
    """Ensure database.db exists and is seeded. Deploy the barracks first."""
    if not os.path.exists(DB_PATH):
        db_seed.run(DB_PATH)


def _load_tables():
    """
    Load all three operational tables into memory.
    Returns: (settings, prompts, functions) as lists of dicts.
    """
    settings  = db.fetch_all_settings(DB_PATH)
    prompts   = db.fetch_all_prompts(DB_PATH)
    functions = db.fetch_all_functions(DB_PATH)
    return settings, prompts, functions


def _resolve_setting(settings, name, fallback=0):
    """Pull a setting value from the loaded settings array by name."""
    for row in settings:
        if row["setting_name"] == name:
            return row["setting_bool"]
    return fallback


def _resolve_prompt(prompts, prompt_name):
    """
    Retrieve the prompt_body for the given prompt_name from the prompts array.
    Exits fatally if the named prompt is not found — a missing default is a
    broken chain of command.
    """
    for row in prompts:
        if row["prompt_name"].upper() == prompt_name.upper() and row["prompt_enabled"]:
            return row["prompt_body"]

    print(f"[index] FATAL — prompt '{prompt_name}' not found or disabled.", file=sys.stderr)
    sys.exit(1)


def _assemble_system_prompt(base_prompt, functions):
    """
    Assemble the full system prompt:
      Part 1 — base prompt body (standing orders)
      Part 2 — sequential digest of enabled function names + descriptions
    """
    lines = [base_prompt, ""]
    enabled_functions = [f for f in functions if f["function_enabled"]]
    for fn in enabled_functions:
        lines.append(f"- {fn['function_name']}: {fn['function_description']}")
    return "\n".join(lines)

# -----------------------------------------------------------------------------
# KOBOLD INTERFACE
# -----------------------------------------------------------------------------

def _call_kobold(system_prompt, user_input):
    """
    Fire a single generate request to Kobold. Returns the stripped response
    string, or an error string prefixed with [ERROR] on failure.

    Prompt format mirrors what Hermes-3 expects:
      <|im_start|>system ... <|im_end|>
      <|im_start|>user   ... <|im_end|>
      <|im_start|>assistant
    """
    prompt = (
        f"<|im_start|>system\n{system_prompt}<|im_end|>\n"
        f"<|im_start|>user\n{user_input}<|im_end|>\n"
        f"<|im_start|>assistant\n"
    )

    payload = json.dumps({
        "prompt":      prompt,
        "max_length":  KOBOLD_MAX_TOKENS,
        "temperature": KOBOLD_TEMPERATURE,
        "top_p":       KOBOLD_TOP_P,
    }).encode("utf-8")

    try:
        req = urllib.request.Request(
            ENDPOINT_KOBOLD,
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=120) as resp:
            body = json.loads(resp.read().decode("utf-8"))
            text = body["results"][0]["text"]
    except urllib.error.URLError as e:
        return f"[ERROR] Kobold unreachable — is it running? ({e.reason})"
    except (KeyError, IndexError, json.JSONDecodeError) as e:
        return f"[ERROR] Unexpected Kobold response format: {e}"

    # Strip anti-prompts from the tail of the response
    for token in ANTI_PROMPTS:
        text = text.split(token)[0]

    return text.strip()

# -----------------------------------------------------------------------------
# FUNCTION EXECUTOR
# -----------------------------------------------------------------------------

def _execute_function(functions, function_name, **kwargs):
    """
    Locate function_name in the loaded functions roster and exec() it.
    Any keyword arguments are injected into the local scope before execution,
    allowing functions like calculate (expr=) and set_setting (setting_name=,
    setting_value=) to receive their parameters.
    Returns the string value of `result` after execution, or an error string.
    """
    fn = next(
        (f for f in functions if f["function_name"] == function_name and f["function_enabled"]),
        None
    )
    if not fn:
        return f"[ERROR] Unknown or disabled function: '{function_name}'"

    local_scope = dict(kwargs)   # pre-seed scope with any supplied parameters
    try:
        exec(fn["function_body"], {}, local_scope)
        return str(local_scope.get("result", "[ERROR] function body set no `result` variable"))
    except Exception as e:
        return f"[ERROR] Exception in '{function_name}': {e}"

# -----------------------------------------------------------------------------
# SCRATCHPAD AGENT LOOP
# -----------------------------------------------------------------------------

def _extract_tool_call(raw, known_functions=None):
    """
    Fallback parser for when the model emits its native <tool_call> format
    instead of our CALL: directive.

    Strategy (in priority order):
      1. Closed <tool_call>...</tool_call> tag — extract inner content.
      2. Open <tool_call>... tag with no closing — grab to end of line.
      3. No tag found — return None immediately.

    Inner content resolution (in priority order):
      A. Valid JSON with a "name" or "function" key — use that value.
      B. First word that exactly matches a known function name — use it.
      C. Scan ALL words in the prose for any known function name — use
         the first match. This handles "I will use get_current_datetime
         to..." where the function name is buried in sentence prose.
      D. Nothing matched — return None.

    known_functions: set/list of valid function_name strings from the
    loaded roster. Without it, step C cannot operate and step B becomes
    an unguarded isidentifier() check (unsafe — accepts 'I', 'First').
    Always pass this from _agent_turn.
    """
    import re, json as _json

    # ── 1 & 2: locate the tag and extract inner text ──────────────────────────
    m = re.search(r'<tool_call>(.*?)</tool_call>', raw, re.DOTALL)
    if not m:
        m = re.search(r'<tool_call>(.*)', raw, re.DOTALL)   # unclosed tag — grab rest
    if not m:
        return None

    inner = m.group(1).strip()
    # Trim at the first newline for unclosed tags so we don't scan paragraphs
    inner = inner.split('\n')[0].strip()

    # ── A: try JSON ───────────────────────────────────────────────────────────
    try:
        parsed = _json.loads(inner)
        candidate = parsed.get("name") or parsed.get("function")
        if candidate and (known_functions is None or candidate in known_functions):
            return candidate
    except (_json.JSONDecodeError, AttributeError):
        pass

    if known_functions is None:
        # No roster — fall back to unsafe first-word check
        first_word = inner.split()[0] if inner else None
        return first_word if (first_word and first_word.isidentifier()) else None

    # ── B: first word is an exact roster hit ─────────────────────────────────
    words = inner.split()
    if words and words[0] in known_functions:
        return words[0]

    # ── C: scan all words for any roster hit (handles buried prose names) ────
    for word in words:
        # Strip trailing punctuation the model might attach (comma, period, etc.)
        clean = word.rstrip('.,;:()')
        if clean in known_functions:
            return clean

    return None


def _parse_call_params(call_line):
    """
    Parse optional key=value parameters from a CALL line.
    The first token is the function name; subsequent tokens are params.
    Handles values that may contain spaces (everything after the key= up to
    the next key= or end of string is captured as the value).

    Examples:
      "get_current_datetime"              -> {}
      "calculate expr=6 * 7"             -> {"expr": "6 * 7"}
      "set_setting setting_name=X setting_value=1"
                                          -> {"setting_name": "X", "setting_value": 1}
    """
    import re
    tokens = call_line.strip().split(None, 1)   # split off function name only
    if len(tokens) < 2:
        return {}

    param_str = tokens[1]
    # Find all key= positions so we can slice values correctly
    pattern = re.compile(r'(\w+)=')
    matches  = list(pattern.finditer(param_str))
    kwargs   = {}
    for idx, m in enumerate(matches):
        key        = m.group(1)
        val_start  = m.end()
        val_end    = matches[idx + 1].start() if idx + 1 < len(matches) else len(param_str)
        raw_val = param_str[val_start:val_end].strip()
        # Strip surrounding quotes if present (single or double, matched or not).
        # The model sometimes quotes values like setting_name="DEBUG_LOGGING" —
        # we must strip those quotes or they become part of the stored key name.
        if raw_val and raw_val[0] in ('"', "'"):
            raw_val = raw_val.strip(raw_val[0])
        # Coerce to int if the value looks like a plain integer
        try:
            kwargs[key] = int(raw_val)
        except ValueError:
            kwargs[key] = raw_val
    return kwargs


MAX_SCRATCHPAD_TURNS = 6   # Hard cap — no infinite hallucination chains

def _agent_turn(system_prompt, user_input, functions):
    """
    Full scratchpad dispatch cycle for one user message.

    Each turn:
      1. Fire Kobold.
      2. Print any <SCRATCHPAD> reasoning live to the terminal.
      3. If CALL: found — execute the real function, print the result, loop.
      4. If FINAL: found (and no CALL:) — print and return.
      5. Otherwise — return raw output verbatim.

    CALL: always beats FINAL: in the same response. If the model pre-hallucinates
    a FINAL: before the real RESULT arrives, we execute the CALL first and let it
    produce a grounded FINAL: on the next turn.
    """
    conversation = user_input

    for _turn in range(MAX_SCRATCHPAD_TURNS):
        raw = _call_kobold(system_prompt, conversation)

        # ── 1. Extract and print <SCRATCHPAD> block live ──────────────────────
        scratch = _extract_tag(raw, "SCRATCHPAD")
        if scratch:
            print(f"\n  [scratchpad] {scratch}")

        # ── 2. Single-pass scan for CALL: and FINAL: directives ───────────────
        call_target = None
        final_lines = []
        for line in raw.splitlines():
            stripped = line.strip()
            if call_target is None and stripped.upper().startswith("CALL:"):
                call_target = stripped[5:].strip()
            if stripped.upper().startswith("FINAL:"):
                final_lines.append(stripped[6:].strip())

        # Fallback: model used its native <tool_call> format instead of CALL:
        # Pass the roster so prose words ('I', 'First', 'To') are rejected.
        if call_target is None:
            _roster = {f["function_name"] for f in functions}
            native_fn = _extract_tool_call(raw, known_functions=_roster)
            if native_fn:
                call_target = native_fn

        # ── 3. CALL: wins — parse optional params, execute, and loop ──────────
        if call_target is not None:
            call_kwargs = _parse_call_params(call_target)
            fn_name     = call_target.split()[0]
            print(f"  → {call_target}")
            fn_result = _execute_function(functions, fn_name, **call_kwargs)
            print(f"  ← {fn_result}")
            conversation = (
                f"{conversation}\n"
                f"{raw}\n"
                f"RESULT: {fn_result}"
            )
            continue

        # ── 4. FINAL: with no outstanding CALL — return grounded answer ───────
        if final_lines:
            return "\n".join(final_lines)

        # ── 5. No directive at all — return whatever the model said ───────────
        return raw

    return "[AGENT] Turn cap reached without final answer."


def _extract_tag(text, tag):
    """Pull the inner content of <TAG>...</TAG> from a string. Returns None if absent."""
    open_tag  = f"<{tag}>"
    close_tag = f"</{tag}>"
    start = text.find(open_tag)
    end   = text.find(close_tag)
    if start == -1 or end == -1 or end <= start:
        return None
    return text[start + len(open_tag):end].strip()

# -----------------------------------------------------------------------------
# COMMAND DISPATCHER  (!commands — never forwarded to the LLM)
# -----------------------------------------------------------------------------

COMMANDS = {
    "!help":      "List all available terminal commands.",
    "!functions": "Display the loaded function roster from the database.",
    "!prompt":    "Print the assembled system prompt currently in use.",
    "!settings":  "Display all settings_boolean values loaded from the database.",
    "!clear":     "Clear the terminal screen.",
}

def _dispatch_command(raw_input, system_prompt, functions, settings):
    """
    Handle any input that begins with '!'. Returns True if the input was a
    command (consumed here), False if it should fall through to the LLM.
    Commands are local only — Kobold never sees them.
    """
    token = raw_input.strip().lower()

    if token == "!help":
        print("\n  Available commands:")
        for cmd, desc in COMMANDS.items():
            print(f"    {cmd:<14} — {desc}")
        print()
        return True

    if token == "!functions":
        enabled = [f for f in functions if f["function_enabled"]]
        if not enabled:
            print("  [functions] No enabled functions loaded.\n")
        else:
            print(f"\n  Loaded functions ({len(enabled)}):")
            for fn in enabled:
                print(f"    • {fn['function_name']}: {fn['function_description']}")
            print()
        return True

    if token == "!prompt":
        print(f"\n--- System Prompt ---\n{system_prompt}\n--- End ---\n")
        return True

    if token == "!settings":
        print("\n  Settings:")
        for s in settings:
            print(f"    {s['setting_name']:<20} = {s['setting_bool']}")
        print()
        return True

    if token == "!clear":
        os.system("clear")
        return True

    # Unknown !command — warn but don't forward
    print(f"  [cmd] Unknown command '{raw_input}'. Type !help for a list.\n")
    return True

# -----------------------------------------------------------------------------
# EXECUTION LOOPS
# -----------------------------------------------------------------------------

def _loop_interactive(system_prompt, functions, settings):
    """
    Interactive readline loop. Kobold is called for every non-command input.
    Commands beginning with '!' are intercepted and handled locally.
    """
    print("  Type '!help' for commands. Type 'exit' or 'quit' to terminate.\n")

    while True:
        try:
            user_input = input("You > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n[index] Session terminated.")
            break

        if not user_input:
            continue

        if user_input.lower() in ("exit", "quit"):
            print("[index] Goodbye.")
            break

        # Intercept all !commands before they reach the LLM
        if user_input.startswith("!"):
            _dispatch_command(user_input, system_prompt, functions, settings)
            continue

        # Forward to scratchpad agent
        print("Agent > ", end="", flush=True)
        response = _agent_turn(system_prompt, user_input, functions)
        print(f"{response}\n")


def _loop_stateless(system_prompt, functions):
    """
    Stateless/daemon loop. Reads from stdin pipe. No terminal output.
    Suitable for cron, daemon, or service deployment.
    Each line of stdin is forwarded to the scratchpad agent; response to stdout.
    """
    for line in sys.stdin:
        user_input = line.strip()
        if not user_input or user_input.startswith("!"):
            continue
        response = _agent_turn(system_prompt, user_input, functions)
        sys.stdout.write(response + "\n")
        sys.stdout.flush()

# -----------------------------------------------------------------------------
# MAIN
# -----------------------------------------------------------------------------

def main():
    # 1. Ensure database exists and is seeded
    _boot_database()

    # 2. Load all tables into memory
    settings, prompts, functions = _load_tables()

    # 3. Resolve the default system prompt
    base_prompt = _resolve_prompt(prompts, DEFAULT_PROMPT)

    # 4. Assemble final system prompt: base + function digest
    system_prompt = _assemble_system_prompt(base_prompt, functions)

    # 5. Evaluate deployment mode from settings
    interactive_mode = _resolve_setting(settings, "INTERACTIVE_MODE", fallback=0)

    # 6. Enter appropriate loop
    if interactive_mode:
        _loop_interactive(system_prompt, functions, settings)
    else:
        _loop_stateless(system_prompt, functions)


if __name__ == "__main__":
    main()
