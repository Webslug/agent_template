# =============================================================================
# db_functions.py
# Canonical roster of seeded agent functions.
# Imported by db_seed.py — never executed directly.
#
# Each entry: (function_name, function_description, function_body, function_language)
# function_body is a string of Python executed via exec() at runtime.
# All function bodies must assign their output to the variable `result`.
# =============================================================================

SEED_FUNCTIONS = [

    # -------------------------------------------------------------------------
    # SYSTEM INFORMATION
    # -------------------------------------------------------------------------

    (
        "get_system_info",
        "Returns basic system information including OS platform, Python version, and current hostname.",
        (
            "import platform\n"
            "import socket\n"
            "info = {\n"
            "    'os':         platform.system(),\n"
            "    'os_version': platform.version(),\n"
            "    'python':     platform.python_version(),\n"
            "    'hostname':   socket.gethostname()\n"
            "}\n"
            "result = str(info)"
        ),
        "python"
    ),

    (
        "get_current_datetime",
        "Returns the current date and time as a formatted string (YYYY-MM-DD HH:MM:SS).",
        (
            "import datetime\n"
            "result = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')"
        ),
        "python"
    ),

    (
        "calculate",
        (
            "Evaluates a Python arithmetic or date expression and returns the result. "
            "Pass the expression as a string assigned to the variable `expr` before calling. "
            "Supports datetime and math operations via pre-injected `datetime` and `math` modules. "
            "Example expr values: "
            "'2 + 2', "
            "'datetime.date(2026,4,5) + datetime.timedelta(days=3)', "
            "'math.sqrt(144)'"
        ),
        (
            "import datetime, math\n"
            "try:\n"
            "    result = str(eval(expr, {'datetime': datetime, 'math': math}))\n"
            "except Exception as e:\n"
            "    result = f'[ERROR] {e}'"
        ),
        "python"
    ),

    # -------------------------------------------------------------------------
    # SETTINGS MANAGEMENT
    # -------------------------------------------------------------------------

    (
        "get_all_settings",
        "Returns all rows from the settings_boolean table as a formatted string.",
        (
            "import sqlite3\n"
            "conn = sqlite3.connect('database.db')\n"
            "rows = conn.execute('SELECT setting_name, setting_bool FROM settings_boolean').fetchall()\n"
            "conn.close()\n"
            "result = '\\n'.join(f'{name} = {val}' for name, val in rows) or '(no settings found)'"
        ),
        "python"
    ),

    (
        "enable_debug_mode",
        "Sets DEBUG_LOGGING to 1 in the settings_boolean table (enables debug mode).",
        (
            "import sqlite3\n"
            "conn = sqlite3.connect('database.db')\n"
            "conn.execute(\"INSERT INTO settings_boolean (setting_name, setting_bool) VALUES ('DEBUG_LOGGING', 1) \"\n"
            "             \"ON CONFLICT(setting_name) DO UPDATE SET setting_bool = 1\")\n"
            "conn.commit()\n"
            "conn.close()\n"
            "result = 'DEBUG_LOGGING set to 1 (debug mode enabled).'"
        ),
        "python"
    ),

    (
        "disable_debug_mode",
        "Sets DEBUG_LOGGING to 0 in the settings_boolean table (disables debug mode).",
        (
            "import sqlite3\n"
            "conn = sqlite3.connect('database.db')\n"
            "conn.execute(\"INSERT INTO settings_boolean (setting_name, setting_bool) VALUES ('DEBUG_LOGGING', 0) \"\n"
            "             \"ON CONFLICT(setting_name) DO UPDATE SET setting_bool = 0\")\n"
            "conn.commit()\n"
            "conn.close()\n"
            "result = 'DEBUG_LOGGING set to 0 (debug mode disabled).'"
        ),
        "python"
    ),

    (
        "set_setting",
        (
            "Sets any named setting in settings_boolean to a given integer value (0 or 1). "
            "Requires two variables set before calling: `setting_name` (str) and `setting_value` (int)."
        ),
        (
            "import sqlite3\n"
            "conn = sqlite3.connect('database.db')\n"
            "conn.execute(\n"
            "    'INSERT INTO settings_boolean (setting_name, setting_bool) VALUES (?, ?) '\n"
            "    'ON CONFLICT(setting_name) DO UPDATE SET setting_bool = ?',\n"
            "    (setting_name, setting_value, setting_value)\n"
            ")\n"
            "conn.commit()\n"
            "conn.close()\n"
            "result = f'{setting_name} set to {setting_value}.'"
        ),
        "python"
    ),

]
